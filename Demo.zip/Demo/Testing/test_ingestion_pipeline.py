# Databricks notebook source
# Remember we only have files from 2022-09-10, 2022-09-11, 2022-09-12
p_file_date = "2022-09-10"

# COMMAND ----------

# If you remember at the end of our python files in the ingestion folder we set a dbutils.notebook.exit("Success")
# We are going to save that value on our v_result variable and display it
# If Success message is displayed that means our notebook runs successfully
v_result = dbutils.notebook.run('../Bronze-silver/customer', 0, {"p_file_date": p_file_date})
v_result

# COMMAND ----------

v_result = dbutils.notebook.run('../Bronze-silver/customerDriver', 0, {"p_file_date": p_file_date})
v_result

# COMMAND ----------

v_result = dbutils.notebook.run('../Bronze-silver/loanTransaction', 0, {"p_file_date": p_file_date})

# COMMAND ----------

# Uncomment this lines when you get to Silver-Gold
# Silver-Gold customer doesn't need the file date param. 
v_result = dbutils.notebook.run('../Silver-Gold/customer', 0)
v_result


# COMMAND ----------

# Uncomment this lines when you get to Silver-Gold
v_result = dbutils.notebook.run('../Silver-Gold/loanTrx', 0, {"p_file_date": p_file_date})
v_result