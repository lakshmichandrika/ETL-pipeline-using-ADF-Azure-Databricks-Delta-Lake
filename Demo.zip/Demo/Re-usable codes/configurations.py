# Databricks notebook source
# Variables that reference containers paths
bronze_folder_path = '/mnt/customeradls/bronze'
silver_folder_path = '/mnt/customeradls/silver'
gold_folder_path = '/mnt/customeradls/gold'